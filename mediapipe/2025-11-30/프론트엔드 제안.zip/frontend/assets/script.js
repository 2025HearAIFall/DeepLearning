/* script.js */
const video = document.getElementById('camera');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

const btnSign = document.getElementById('btn-sign');
const btnVoice = document.getElementById('btn-voice');
// const audioInput = document.getElementById('audioInput'); // 사용하지 않음

const chatBox = document.getElementById('chat-box');
const progressBar = document.getElementById('progressBar');
const statusBadge = document.getElementById('status-badge');

let intervalId = null; // 수어/음성 녹화/녹음 간격 제어
let mediaRecorder = null; // 음성 녹음 제어

// 카메라 켜기
navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
    .then(stream => { video.srcObject = stream; })
    .catch(err => alert("카메라 권한 필요"));

// 💬 말풍선 추가 함수 (기존 유지)
function addMessage(type, text, subText = null) {
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('message');
    
    if (type === 'sign') {
        msgDiv.classList.add('msg-sign');
        let html = `<span class="name">🖐 수어 통역</span>${text}`;
        if (subText && subText !== text && subText !== "...") {
            html += `<span class="correction-text">🧩 ${subText}</span>`;
        }
        msgDiv.innerHTML = html;
    } else {
        msgDiv.classList.add('msg-voice');
        msgDiv.innerHTML = text;
    }

    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// 🖐 수어 녹화 (5초) - 기존 유지
btnSign.addEventListener('click', async () => {
    if (intervalId || mediaRecorder) return; // 이미 녹화/녹음 중이면 무시

    btnSign.disabled = true;
    btnVoice.disabled = true;
    statusBadge.innerText = "🔴 준비 중...";
    statusBadge.style.color = "#ff4b4b";
    progressBar.style.width = "0%";

    try {
        // 1. 서버 리셋 먼저 수행
        await fetch("http://127.0.0.1:8000/api/reset", { method: "POST" });
        
        // 2. 프레임 전송 시작 (100ms 간격)
        intervalId = setInterval(sendFrame, 100); 
        
    } catch (err) {
        console.error(err);
        resetUI();
    }
});

async function sendFrame() {
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const frameData = canvas.toDataURL('image/jpeg', 0.5);

    try {
        const res = await fetch("http://127.0.0.1:8000/api/sign_infer", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ "frame": frameData })
        });
        const data = await res.json();

        if (data.status === "recording") {
            const pct = data.progress;
            progressBar.style.width = pct + "%";
            // 5초 카운트다운 표시
            statusBadge.innerText = `🔴 녹화 중 (${pct}%)`;
        } else if (data.status === "done") {
            stopRecording();
            
            // 결과 표시
            addMessage('sign', data.translation, data.corrected);
            speakText(data.corrected || data.translation);
        }
    } catch (err) {
        console.error(err);
        stopRecording();
    }
}

function stopRecording() {
    if (intervalId) { clearInterval(intervalId); intervalId = null; }
    resetUI();
}

function resetUI() {
    btnSign.disabled = false;
    btnVoice.disabled = false;
    statusBadge.innerText = "대기 중";
    statusBadge.style.color = "white";
    progressBar.style.width = "0%";
}


// ==============================================================
// 🎤 음성 녹음 (5초 실시간 녹음 로직) - 수정됨
// ==============================================================
btnVoice.addEventListener('click', async () => {
    if (intervalId) return; // 이미 녹화/녹음 중이면 무시

    btnSign.disabled = true;
    btnVoice.disabled = true;
    statusBadge.innerText = "🎤 마이크 준비 중...";
    statusBadge.style.color = "#ffeb33";
    progressBar.style.width = "0%";

    try {
        // 1. 마이크 권한 요청 및 스트림 획득
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        mediaRecorder = new MediaRecorder(stream);
        let audioChunks = [];

        // 데이터가 들어올 때마다 배열에 저장
        mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                audioChunks.push(event.data);
            }
        };

        // 녹음이 멈췄을 때 서버로 전송
        mediaRecorder.onstop = async () => {
            // 스트림 트랙 종료 (마이크 끄기)
            stream.getTracks().forEach(track => track.stop());

            statusBadge.innerText = "🎤 분석 중...";
            
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            
            await sendAudioToServer(audioBlob);
            mediaRecorder = null; // 정리
        };

        // 2. 녹음 시작
        mediaRecorder.start();
        
        // 3. 5초 카운트다운 (Progress Bar & 상태 메시지)
        let progress = 0;
        statusBadge.innerText = "🎤 녹음 중 (0%)";
        
        intervalId = setInterval(() => {
            progress += 2; // 100ms * 50회 = 5000ms (5초)
            if (progress > 100) progress = 100;
            
            progressBar.style.width = `${progress}%`;
            statusBadge.innerText = `🎤 녹음 중 (${progress}%)`;

            // 5초 도달 시 종료
            if (progress >= 100) {
                clearInterval(intervalId);
                intervalId = null;
                mediaRecorder.stop(); // 녹음 종료 트리거 -> onstop 실행됨
            }
        }, 100); 

    } catch (err) {
        console.error("마이크 접근 실패:", err);
        alert("마이크 사용 권한이 필요합니다.");
        resetUI();
    }
});

// 서버로 오디오 전송 함수
async function sendAudioToServer(blob) {
    const formData = new FormData();
    // 파일명은 temp.webm으로 설정하여 Flask에서 파일로 읽을 수 있도록 함
    formData.append("audio", blob, "temp_audio.webm");

    try {
        const res = await fetch("http://127.0.0.1:8000/api/voice_infer", { 
            method: "POST", 
            body: formData 
        });
        
        if (!res.ok) throw new Error("Server Error");
        
        const data = await res.json();
        const text = data.recognized_text;
        const emo = data.emotion;
        
        addMessage('voice', `${text} <small>(${emo})</small>`);
    } catch (err) { 
        console.error(err);
        alert("음성 분석 중 오류가 발생했습니다."); 
    } finally { 
        resetUI(); 
    }
}

function speakText(text) {
    if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = 'ko-KR';
        window.speechSynthesis.speak(utter);
    }
}