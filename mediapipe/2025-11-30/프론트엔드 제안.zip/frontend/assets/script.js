const video = document.getElementById('camera');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

const btnSign = document.getElementById('btn-sign');
const btnVoice = document.getElementById('btn-voice');
const audioInput = document.getElementById('audioInput');

const chatBox = document.getElementById('chat-box');
const progressBar = document.getElementById('progressBar');
const statusBadge = document.getElementById('status-badge');

let intervalId = null;

// 카메라 켜기
navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
    .then(stream => { video.srcObject = stream; })
    .catch(err => alert("카메라 권한 필요"));

// 💬 말풍선 추가 함수
function addMessage(type, text, subText = null) {
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('message');
    
    if (type === 'sign') {
        msgDiv.classList.add('msg-sign');
        let html = `<span class="name">🖐 수어 통역</span>${text}`;
        if (subText && subText !== text && subText !== "...") {
            html += `<span class="correction-text">🧩 ${subText}</span>`;
        }
        msgDiv.innerHTML = html;
    } else {
        msgDiv.classList.add('msg-voice');
        msgDiv.innerHTML = text;
    }

    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// 🖐 수어 녹화 (5초)
btnSign.addEventListener('click', async () => {
    if (intervalId) return;

    btnSign.disabled = true;
    btnVoice.disabled = true;
    statusBadge.innerText = "🔴 준비 중...";
    statusBadge.style.color = "#ff4b4b";
    progressBar.style.width = "0%";

    try {
        // 1. 서버 리셋 먼저 수행
        await fetch("http://127.0.0.1:8000/api/reset", { method: "POST" });
        
        // 2. 프레임 전송 시작 (100ms 간격 = 1초에 10장)
        // 🔥 여기가 핵심 변경점 (33 -> 100)
        intervalId = setInterval(sendFrame, 100); 
        
    } catch (err) {
        console.error(err);
        resetUI();
    }
});

async function sendFrame() {
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const frameData = canvas.toDataURL('image/jpeg', 0.5);

    try {
        const res = await fetch("http://127.0.0.1:8000/api/sign_infer", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ "frame": frameData })
        });
        const data = await res.json();

        if (data.status === "recording") {
            const pct = data.progress;
            progressBar.style.width = pct + "%";
            // 5초 카운트다운 표시
            statusBadge.innerText = `🔴 녹화 중 (${pct}%)`;
        } else if (data.status === "done") {
            stopRecording();
            
            // 결과 표시
            addMessage('sign', data.translation, data.corrected);
            speakText(data.corrected || data.translation);
        }
    } catch (err) {
        console.error(err);
        stopRecording();
    }
}

function stopRecording() {
    if (intervalId) { clearInterval(intervalId); intervalId = null; }
    resetUI();
}

function resetUI() {
    btnSign.disabled = false;
    btnVoice.disabled = false;
    statusBadge.innerText = "대기 중";
    statusBadge.style.color = "white";
    progressBar.style.width = "0%";
}

// 🎤 음성 (기존 유지)
btnVoice.addEventListener('click', () => { audioInput.click(); });
audioInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    statusBadge.innerText = "🎤 분석 중...";
    const formData = new FormData();
    formData.append("audio", file);
    try {
        const res = await fetch("http://127.0.0.1:8000/api/voice_infer", { method: "POST", body: formData });
        const data = await res.json();
        const text = data.recognized_text;
        const emo = data.emotion;
        addMessage('voice', `${text} <small>(${emo})</small>`);
    } catch (err) { alert("오류"); } finally { resetUI(); audioInput.value = ""; }
});

function speakText(text) {
    if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = 'ko-KR';
        window.speechSynthesis.speak(utter);
    }
}