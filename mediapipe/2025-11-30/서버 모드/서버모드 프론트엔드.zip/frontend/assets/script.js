// ============================================
// Socket.IO 기반 실시간 채팅 클라이언트
// ============================================

// 1. 소켓 연결 (현재 주소 기준)
const socket = io();

const video = document.getElementById('camera');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const btnSign = document.getElementById('btn-sign');
const btnVoice = document.getElementById('btn-voice');
const chatBox = document.getElementById('chat-box');
const progressBar = document.getElementById('progressBar');
const statusBadge = document.getElementById('status-badge');

let intervalId = null;
let mediaRecorder = null;
let audioChunks = [];

// 카메라 시작
navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: true })
    .then(stream => {
        video.srcObject = stream;
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
    })
    .catch(err => alert("카메라/마이크 권한 필요"));

// ============================================
// 👂 소켓 이벤트 리스너 (서버 -> 클라이언트)
// ============================================

// 1. 서버 접속 확인
socket.on('server_msg', (data) => {
    console.log(data.text);
});

// 2. 새로운 메시지 도착 (남이 말한 것 or 내가 말한 것)
socket.on('new_message', (data) => {
    // 내가 보낸 건지 남이 보낸 건지 구별
    const isMine = data.sender === socket.id;
    
    let displayType = 'voice'; // 기본값 (상대방 음성 등)
    
    if (data.type === 'sign') {
        // 수어는 무조건 왼쪽(상대방) 처럼 보이게 할 수도 있고, 
        // 카톡처럼 내껀 오른쪽, 남껀 왼쪽으로 할 수도 있습니다.
        // 여기서는 '내껀 오른쪽(voice style)', '남껀 왼쪽(sign style)'로 통일하거나
        // 원본 로직대로 '수어=왼쪽', '음성=오른쪽' 유지할 수 있습니다.
        
        // [수정된 로직] 채팅앱스럽게:
        // 내가 보낸 것 -> 오른쪽 (노란색)
        // 남이 보낸 것 -> 왼쪽 (흰색)
        addChatMessage(isMine, data.text, data.subText || `(${data.emotion || ''})`);
    } 
    else {
        // 음성
        addChatMessage(isMine, data.text, data.emotion ? `<small>(${data.emotion})</small>` : '');
    }

    // TTS 읽기 (내가 보낸 게 아닐 때만 읽기)
    if (!isMine) {
        speakText(data.subText || data.text);
    }
});

// 3. 녹화 진행률 업데이트 (나한테만 옴)
socket.on('record_progress', (data) => {
    const pct = data.progress;
    progressBar.style.width = pct + "%";
    statusBadge.innerText = `🔴 녹화 중 ${pct}%`;
});

// 4. 녹화/분석 완료 (나한테만 옴)
socket.on('record_done', () => {
    stopSignRecording();
});

// ============================================
// 📤 전송 로직 (클라이언트 -> 서버)
// ============================================

// UI 헬퍼: 말풍선 그리기
function addChatMessage(isMine, text, subInfo) {
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('message');
    
    if (isMine) {
        msgDiv.classList.add('msg-voice'); // 내꺼 (오른쪽)
        msgDiv.innerHTML = `${text} ${subInfo ? subInfo : ''}`;
    } else {
        msgDiv.classList.add('msg-sign'); // 남꺼 (왼쪽)
        let html = `<span class="name">상대방</span>${text}`;
        if (subInfo) html += `<span class="correction-text">🧩 ${subInfo}</span>`;
        msgDiv.innerHTML = html;
    }
    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// 🖐 수어 시작
btnSign.addEventListener('click', () => {
    if (intervalId) return;
    btnSign.disabled = true; btnVoice.disabled = true;
    socket.emit('request_reset'); // 서버 버퍼 비우기
    statusBadge.innerText = "준비 중...";
    intervalId = setInterval(() => {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const frameData = canvas.toDataURL('image/jpeg', 0.5);
        socket.emit('send_frame', { frame: frameData }); // 소켓 전송
    }, 100); // 10FPS
});

function stopSignRecording() {
    if (intervalId) { clearInterval(intervalId); intervalId = null; }
    btnSign.disabled = false; btnVoice.disabled = false;
    statusBadge.innerText = "대기 중";
    progressBar.style.width = "0%";
}

// 🎤 음성 시작
btnVoice.addEventListener('click', () => {
    if (!mediaRecorder || mediaRecorder.state === 'recording') return;
    btnSign.disabled = true; btnVoice.disabled = true;
    statusBadge.innerText = "🎤 녹음 중...";
    statusBadge.style.color = "#007bff";
    
    audioChunks = [];
    mediaRecorder.start();
    
    setTimeout(() => {
        if (mediaRecorder.state === 'recording') mediaRecorder.stop();
    }, 5000); // 5초

    mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunks, { type: 'audio/wav' });
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
            statusBadge.innerText = "전송 중...";
            socket.emit('send_voice', { audio_data: reader.result }); // 소켓 전송
            
            // UI 복구
            btnSign.disabled = false; btnVoice.disabled = false;
            statusBadge.innerText = "대기 중";
            statusBadge.style.color = "white";
        };
    };
});

function speakText(text) {
    if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = 'ko-KR';
        window.speechSynthesis.speak(utter);
    }
}